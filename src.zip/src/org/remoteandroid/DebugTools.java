package org.remoteandroid;

//import org.acra.ErrorReporter;

public class DebugTools
{
	static public void handleException(Throwable e)
	{
//		ErrorReporter.getInstance().handleException(e);
	}
	static public void handleSilentException(Throwable e)
	{
//		ErrorReporter.getInstance().handleSilentException(e);
	}
}
