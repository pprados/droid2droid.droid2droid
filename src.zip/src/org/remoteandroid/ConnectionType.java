package org.remoteandroid;

public enum ConnectionType { ETHERNET,BT,GSM};
